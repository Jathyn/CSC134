// CSC 134
// M1HW1
// Your Name
// The Date

#include <iostream>
using namespace std;

int main() {
    // This program will display information about a movie

    // Movie Name
    string movieName = "The Lion King";

    // Year of Release
    int releaseYear = 1994;

    // Box Office Gross (in billion dollars)
    double boxOfficeGross = 1.6;

    // Print movie information
    cout << "Movie Information" << endl;
    cout << "-----------------" << endl;
    cout << "Movie: " << movieName << endl;
    cout << "Year Released: " << releaseYear << endl;
    cout << "Box Office Gross: $" << boxOfficeGross << " billion" << endl;
    cout << endl; // Blank line to separate sections

    // Favorite Quotes or Fun Facts
    cout << "Interesting Facts:" << endl;
    cout << "\"Hakuna Matata! It means no worries.\" - Timon & Pumbaa" << endl;
    cout << "The Lion King is one of Disney's most popular animated movies." << endl;
    cout << "It was nominated for 4 Academy Awards and won 2 of them." << endl;
    cout << "The movie's soundtrack was composed by Hans Zimmer." << endl;

    return 0;
}
