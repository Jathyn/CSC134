// CSC 134
// Assignment Name: M1T2
// Your Name: Jathyn Mcleod
// Date: February 23, 2025

#include <iostream>
using namespace std;

int main() {
    // Printing the required lines of text
    cout << "My name is Jathyn Mcleod." << endl;
    cout << "I am enrolled in the Computer Programming program." << endl;
    cout << "In my free time, I enjoy hiking, coding, and reading science fiction." << endl;

    return 0;
}
