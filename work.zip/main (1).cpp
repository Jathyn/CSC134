// standard comment header goes here

#include <iostream>

int main() { std::cout << "Hello CSC134!\n"; }