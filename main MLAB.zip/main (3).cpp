// CSC 134
// M1LAB
// Your Name
// The Date

#include <iostream>
using namespace std;

int main() {
    // This program will simulate an apple orchard.

    // The owner’s name
    string name = "Your Name";

    // Number of apples owned
    int apples = 100;

    // Price per apple
    double pricePerApple = 0.25;

    // Calculate the total price of the apples
    double totalPrice = apples * pricePerApple;

    // Print all the information about the orchard
    cout << "Welcome to " << name << "’s apple orchard." << endl;
    cout << "We have " << apples << " apples in stock." << endl;
    cout << "Apples are currently $" << pricePerApple << " each." << endl;
    cout << "If you want them all, that will be $" << totalPrice << "." << endl;

    return 0;
}
